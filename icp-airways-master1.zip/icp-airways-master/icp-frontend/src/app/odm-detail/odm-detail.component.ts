import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-odm-detail',
  templateUrl: './odm-detail.component.html',
  styleUrls: ['./odm-detail.component.css']
})
export class OdmDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
